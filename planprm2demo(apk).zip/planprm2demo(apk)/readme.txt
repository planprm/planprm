1 - Разархивируйте Архив(zip) * можете через компьютер или другим zip-архиватором, к примеру: 'Data/app/'
2 - Найдите и кликните на planprm2demo.
3 - Кликните на 'установить'.
4 - После установки выйдите в стартовое меню.
5 - Кликните на planprm1demo или planprm2demo
автор: Исмагилов А.З.
email:progamailism@gmail.com
twitter:https://twitter.com/AmirIsmagilov
сайт: 1 - https://snoocppy.github.io/
      2 - https://myiazblog.wordpress.com 